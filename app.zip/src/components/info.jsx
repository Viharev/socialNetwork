import './../main.css'

const info = () => {
    return (
        <div>
            <div className="info">
                <div className="photo"></div>
                <div className="list">
                    <h2>viharev nikolay</h2>
                    <ul>
                        <li>Date of birth: 27.01.1989</li>
                        <li>City: Kirov</li>
                        <li>Ed. VyatskayaGSHa</li>
                        <li>web site: <a href="https://vk.com/vikharev.na">vk.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default info;