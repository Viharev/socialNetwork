import './../footer.css';

const footer = () => {
    return(
        <div className='footer'>
            <h1>this is footer!!!!!!</h1>
        </div>
    )
}

export default footer;