

const inputPosts = () => {
    return(
        <div>
            <div className="posts">
                <p>hello, this is my first post</p>
            </div>
        </div>
    )
}

export default inputPosts;