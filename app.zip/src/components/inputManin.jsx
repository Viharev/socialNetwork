

const inputManin = () => {
    return (
        <div>
            <div className='inputContent'>
                <input></input>
                <div><button>sending</button></div>
            </div>
        </div>
    )
}

export default inputManin;